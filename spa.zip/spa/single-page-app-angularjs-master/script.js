var app=angular.module('single-page-app',['ngRoute']);


app.config(function($routeProvider){


      $routeProvider
          .when('/brands',{
                templateUrl: 'brands.html'
          })
          .when('/jasonjenkinslive',{
                templateUrl: 'jasonjenkinslive.html'
          })
          .when('/burntlabel',{
                templateUrl: 'burntlabel.html'
          })
          .when('/rastadread',{
                templateUrl: 'rastadread.html'
          })
          .when('/jasonjenkinsprints',{
                templateUrl: 'jasonjenkinsprints.html'
          })
          .when('/greenlabels',{
                templateUrl: 'greenlabels.html'
          })
          .when('/blackmanic',{
                templateUrl: 'blackmanic.html'
          })
          .when('/officedrip',{
                templateUrl: 'officedrip.html'
          });


});


app.controller('cfgController',function($scope){

      $scope.message="Hello world";

});
